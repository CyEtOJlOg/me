from django.shortcuts import render

def index(reguest):
    return render(request, 'index.html')